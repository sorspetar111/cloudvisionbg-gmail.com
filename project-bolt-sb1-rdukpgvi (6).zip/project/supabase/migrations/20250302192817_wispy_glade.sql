-- Weather Forecast Application Stored Procedures and Functions
-- This script creates stored procedures and functions for the Weather Forecast application

DELIMITER //

-- Procedure to get active subscriptions
CREATE PROCEDURE GetActiveSubscriptions()
BEGIN
    SELECT 
        s.id AS subscription_id,
        u.id AS user_id,
        u.name AS user_name,
        u.email AS user_email,
        u.location AS user_location,
        p.name AS plan_name,
        s.start_date,
        s.end_date
    FROM 
        subscriptions s
    JOIN 
        users u ON s.user_id = u.id
    JOIN 
        plans p ON s.plan_id = p.id
    WHERE 
        s.status = 'active'
        AND s.end_date > NOW();
END //

-- Procedure to get expired subscriptions
CREATE PROCEDURE GetExpiredSubscriptions()
BEGIN
    SELECT 
        s.id AS subscription_id,
        u.id AS user_id,
        u.name AS user_name,
        u.email AS user_email,
        p.name AS plan_name,
        s.start_date,
        s.end_date
    FROM 
        subscriptions s
    JOIN 
        users u ON s.user_id = u.id
    JOIN 
        plans p ON s.plan_id = p.id
    WHERE 
        s.status = 'active'
        AND s.end_date <= NOW();
END //

-- Procedure to update expired subscriptions
CREATE PROCEDURE UpdateExpiredSubscriptions()
BEGIN
    UPDATE subscriptions
    SET status = 'expired'
    WHERE status = 'active' AND end_date <= NOW();
    
    SELECT ROW_COUNT() AS updated_count;
END //

-- Function to check if a user has an active subscription
CREATE FUNCTION HasActiveSubscription(user_id BIGINT) RETURNS BOOLEAN
DETERMINISTIC
BEGIN
    DECLARE subscription_count INT;
    
    SELECT COUNT(*) INTO subscription_count
    FROM subscriptions
    WHERE user_id = user_id AND status = 'active' AND end_date > NOW();
    
    RETURN subscription_count > 0;
END //

-- Procedure to get users who should receive weather forecasts today
CREATE PROCEDURE GetUsersForWeatherForecast()
BEGIN
    SELECT 
        u.id AS user_id,
        u.name AS user_name,
        u.email AS user_email,
        u.location AS user_location
    FROM 
        users u
    JOIN 
        subscriptions s ON u.id = s.user_id
    WHERE 
        s.status = 'active'
        AND s.end_date > NOW()
        AND u.location IS NOT NULL;
END //

DELIMITER ;
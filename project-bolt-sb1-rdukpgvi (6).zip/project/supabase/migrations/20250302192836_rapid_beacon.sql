-- Weather Forecast Application Database Indexes
-- This script creates additional indexes for the Weather Forecast application

-- Add index for user location to optimize weather forecast queries
ALTER TABLE users ADD INDEX idx_user_location (location);

-- Add composite index for subscription status and dates
ALTER TABLE subscriptions ADD INDEX idx_subscription_status_dates (status, start_date, end_date);

-- Add index for email searches
ALTER TABLE users ADD INDEX idx_user_email (email);

-- Add index for plan active status
ALTER TABLE plans ADD INDEX idx_plan_active (is_active);

-- Add index for jobs processing
ALTER TABLE jobs ADD INDEX idx_jobs_reserved_available (reserved_at, available_at);
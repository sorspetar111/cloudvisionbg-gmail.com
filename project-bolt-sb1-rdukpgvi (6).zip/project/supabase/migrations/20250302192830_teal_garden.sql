-- Weather Forecast Application Database Views
-- This script creates views for the Weather Forecast application

-- View for active subscriptions with user and plan details
CREATE OR REPLACE VIEW active_subscriptions_view AS
SELECT 
    s.id AS subscription_id,
    u.id AS user_id,
    u.name AS user_name,
    u.email AS user_email,
    u.location AS user_location,
    p.id AS plan_id,
    p.name AS plan_name,
    p.price AS plan_price,
    s.payment_method,
    s.start_date,
    s.end_date,
    DATEDIFF(s.end_date, CURRENT_DATE()) AS days_remaining
FROM 
    subscriptions s
JOIN 
    users u ON s.user_id = u.id
JOIN 
    plans p ON s.plan_id = p.id
WHERE 
    s.status = 'active'
    AND s.end_date > NOW();

-- View for subscription statistics
CREATE OR REPLACE VIEW subscription_statistics AS
SELECT
    p.id AS plan_id,
    p.name AS plan_name,
    COUNT(s.id) AS total_subscriptions,
    SUM(CASE WHEN s.status = 'active' THEN 1 ELSE 0 END) AS active_subscriptions,
    SUM(CASE WHEN s.status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled_subscriptions,
    SUM(CASE WHEN s.status = 'expired' THEN 1 ELSE 0 END) AS expired_subscriptions,
    AVG(DATEDIFF(s.end_date, s.start_date)) AS avg_subscription_length_days
FROM
    plans p
LEFT JOIN
    subscriptions s ON p.id = s.plan_id
GROUP BY
    p.id, p.name;

-- View for users who should receive weather forecasts
CREATE OR REPLACE VIEW users_for_weather_forecast AS
SELECT 
    u.id AS user_id,
    u.name AS user_name,
    u.email AS user_email,
    u.location AS user_location
FROM 
    users u
JOIN 
    subscriptions s ON u.id = s.user_id
WHERE 
    s.status = 'active'
    AND s.end_date > NOW()
    AND u.location IS NOT NULL;
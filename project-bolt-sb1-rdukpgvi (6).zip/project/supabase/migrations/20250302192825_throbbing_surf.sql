-- Weather Forecast Application Database Triggers
-- This script creates triggers for the Weather Forecast application

DELIMITER //

-- Trigger to log subscription status changes
CREATE TRIGGER after_subscription_status_change
AFTER UPDATE ON subscriptions
FOR EACH ROW
BEGIN
    IF OLD.status != NEW.status THEN
        INSERT INTO subscription_logs (subscription_id, old_status, new_status, changed_at)
        VALUES (NEW.id, OLD.status, NEW.status, NOW());
    END IF;
END //

-- Create subscription_logs table first
CREATE TABLE IF NOT EXISTS subscription_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    subscription_id BIGINT UNSIGNED NOT NULL,
    old_status VARCHAR(255) NOT NULL,
    new_status VARCHAR(255) NOT NULL,
    changed_at TIMESTAMP NOT NULL,
    FOREIGN KEY (subscription_id) REFERENCES subscriptions (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci //

-- Trigger to ensure user has a location before creating a subscription
CREATE TRIGGER before_subscription_insert
BEFORE INSERT ON subscriptions
FOR EACH ROW
BEGIN
    DECLARE user_location VARCHAR(255);
    
    SELECT location INTO user_location
    FROM users
    WHERE id = NEW.user_id;
    
    IF user_location IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'User must have a location set before subscribing';
    END IF;
END //

DELIMITER ;
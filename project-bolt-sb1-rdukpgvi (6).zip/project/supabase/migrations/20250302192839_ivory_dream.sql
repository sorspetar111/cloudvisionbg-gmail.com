-- Weather Forecast Application Complete Database Script
-- This script combines all database components into a single file

-- Include schema
SOURCE weather_forecast_schema.sql;

-- Include views
SOURCE weather_forecast_views.sql;

-- Include procedures
SOURCE weather_forecast_procedures.sql;

-- Include triggers
SOURCE weather_forecast_triggers.sql;

-- Include indexes
SOURCE weather_forecast_indexes.sql;

-- Additional configuration
SET GLOBAL event_scheduler = ON;

-- Create event to automatically check for expired subscriptions
DELIMITER //
CREATE EVENT IF NOT EXISTS check_expired_subscriptions
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_DATE + INTERVAL 1 DAY
DO
BEGIN
    CALL UpdateExpiredSubscriptions();
END //
DELIMITER ;

-- Final setup message
SELECT 'Weather Forecast Database Setup Complete' AS 'Status';
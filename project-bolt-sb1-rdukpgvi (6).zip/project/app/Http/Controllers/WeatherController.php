<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Mail\WeatherForecastMail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class WeatherController extends Controller
{
    /**
     * Get weather forecast for the authenticated user
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function getWeatherForecast(Request $request)
    {
        $user = auth()->user();
        
        if (!$user) {
            return response()->json(['error' => 'Unauthenticated'], 401);
        }
        
        if (!$user->location) {
            return response()->json(['error' => 'User location not set'], 400);
        }
        
        // Fetch weather data from external API or service
        $weatherData = $this->fetchWeatherData($user->location);
        
        return response()->json([
            'success' => true,
            'data' => $weatherData
        ]);
    }
    
    /**
     * Send weather forecast email to the user
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function sendWeatherEmail(Request $request)
    {
        $user = auth()->user();
        
        if (!$user) {
            return response()->json(['error' => 'Unauthenticated'], 401);
        }
        
        if (!$user->location) {
            return response()->json(['error' => 'User location not set'], 400);
        }
        
        // Fetch weather data
        $weatherData = $this->fetchWeatherData($user->location);
        
        // Send email with weather forecast
        Mail::to($user->email)->queue(new WeatherForecastMail($weatherData));
        
        return response()->json([
            'success' => true,
            'message' => 'Weather forecast email has been queued for delivery'
        ]);
    }
    
    /**
     * Fetch weather data from external service
     *
     * @param string $location
     * @return array
     */
    private function fetchWeatherData($location)
    {
        $apiKey = config('services.weather.api_key');
        $apiUrl = config('services.weather.api_url');
        
        // If API key and URL are configured, try to fetch real data
        if ($apiKey && $apiUrl) {
            try {
                $response = Http::get($apiUrl, [
                    'key' => $apiKey,
                    'q' => $location,
                    'days' => 2
                ]);
                
                if ($response->successful()) {
                    $data = $response->json();
                    // Process and format the API response
                    return $this->formatWeatherData($data, $location);
                }
            } catch (\Exception $e) {
                Log::error('Weather API error: ' . $e->getMessage());
            }
        }
        
        // Fallback to placeholder data if API call fails or not configured
        return [
            'location' => $location,
            'temperature' => rand(0, 30),
            'condition' => ['Sunny', 'Cloudy', 'Rainy', 'Snowy'][rand(0, 3)],
            'forecast' => [
                'today' => ['high' => rand(15, 30), 'low' => rand(0, 15)],
                'tomorrow' => ['high' => rand(15, 30), 'low' => rand(0, 15)],
            ]
        ];
    }
    
    /**
     * Format weather data from API response
     *
     * @param array $data
     * @param string $location
     * @return array
     */
    private function formatWeatherData($data, $location)
    {
        // This would be implemented based on the structure of your weather API response
        // Placeholder implementation
        return [
            'location' => $location,
            'temperature' => $data['current']['temp_c'] ?? rand(0, 30),
            'condition' => $data['current']['condition']['text'] ?? ['Sunny', 'Cloudy', 'Rainy', 'Snowy'][rand(0, 3)],
            'forecast' => [
                'today' => [
                    'high' => $data['forecast']['forecastday'][0]['day']['maxtemp_c'] ?? rand(15, 30),
                    'low' => $data['forecast']['forecastday'][0]['day']['mintemp_c'] ?? rand(0, 15)
                ],
                'tomorrow' => [
                    'high' => $data['forecast']['forecastday'][1]['day']['maxtemp_c'] ?? rand(15, 30),
                    'low' => $data['forecast']['forecastday'][1]['day']['mintemp_c'] ?? rand(0, 15)
                ],
            ]
        ];
    }
}
<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\User;
use App\Mail\WeatherForecastMail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;

class SendWeatherForecasts extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:send-weather-forecasts';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send weather forecasts to subscribed users';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $users = User::whereHas('subscriptions', function ($query) {
            $query->where('status', 'active');
        })->get();

        $this->info("Sending weather forecasts to {$users->count()} users");

        foreach ($users as $user) {
            if (!$user->location) {
                $this->warn("User {$user->id} has no location set, skipping");
                continue;
            }

            try {
                // Fetch weather data
                $weatherData = $this->fetchWeatherData($user->location);
                
                // Queue email for sending
                Mail::to($user->email)->queue(new WeatherForecastMail($weatherData));
                
                $this->info("Queued forecast for {$user->email}");
            } catch (\Exception $e) {
                $this->error("Failed to send forecast to {$user->email}: {$e->getMessage()}");
                Log::error("Weather forecast email error: {$e->getMessage()}");
            }
        }

        $this->info('Weather forecasts queued successfully');
    }

    /**
     * Fetch weather data from external service
     *
     * @param string $location
     * @return array
     */
    private function fetchWeatherData($location)
    {
        $apiKey = config('services.weather.api_key');
        $apiUrl = config('services.weather.api_url');
        
        // If API key and URL are configured, try to fetch real data
        if ($apiKey && $apiUrl) {
            try {
                $response = Http::get($apiUrl, [
                    'key' => $apiKey,
                    'q' => $location,
                    'days' => 2
                ]);
                
                if ($response->successful()) {
                    $data = $response->json();
                    // Process and format the API response
                    return $this->formatWeatherData($data, $location);
                }
            } catch (\Exception $e) {
                Log::error('Weather API error: ' . $e->getMessage());
            }
        }
        
        // Fallback to placeholder data if API call fails or not configured
        return [
            'location' => $location,
            'temperature' => rand(0, 30),
            'condition' => ['Sunny', 'Cloudy', 'Rainy', 'Snowy'][rand(0, 3)],
            'forecast' => [
                'today' => ['high' => rand(15, 30), 'low' => rand(0, 15)],
                'tomorrow' => ['high' => rand(15, 30), 'low' => rand(0, 15)],
            ]
        ];
    }
    
    /**
     * Format weather data from API response
     *
     * @param array $data
     * @param string $location
     * @return array
     */
    private function formatWeatherData($data, $location)
    {
        // This would be implemented based on the structure of your weather API response
        // Placeholder implementation
        return [
            'location' => $location,
            'temperature' => $data['current']['temp_c'] ?? rand(0, 30),
            'condition' => $data['current']['condition']['text'] ?? ['Sunny', 'Cloudy', 'Rainy', 'Snowy'][rand(0, 3)],
            'forecast' => [
                'today' => [
                    'high' => $data['forecast']['forecastday'][0]['day']['maxtemp_c'] ?? rand(15, 30),
                    'low' => $data['forecast']['forecastday'][0]['day']['mintemp_c'] ?? rand(0, 15)
                ],
                'tomorrow' => [
                    'high' => $data['forecast']['forecastday'][1]['day']['maxtemp_c'] ?? rand(15, 30),
                    'low' => $data['forecast']['forecastday'][1]['day']['mintemp_c'] ?? rand(0, 15)
                ],
            ]
        ];
    }
}
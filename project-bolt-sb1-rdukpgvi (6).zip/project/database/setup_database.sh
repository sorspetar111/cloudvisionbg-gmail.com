#!/bin/bash

# Database setup script for Weather Forecast Application

# Configuration
DB_NAME="weather_forecast"
DB_USER="root"
DB_PASSWORD=""
DB_HOST="localhost"

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}Setting up Weather Forecast Database...${NC}"

# Create database if it doesn't exist
echo -e "${YELLOW}Creating database if it doesn't exist...${NC}"
mysql -h $DB_HOST -u $DB_USER ${DB_PASSWORD:+-p$DB_PASSWORD} -e "CREATE DATABASE IF NOT EXISTS $DB_NAME CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

if [ $? -eq 0 ]; then
    echo -e "${GREEN}Database created or already exists.${NC}"
else
    echo -e "${RED}Failed to create database.${NC}"
    exit 1
fi

# Run the main schema script
echo -e "${YELLOW}Creating database schema...${NC}"
mysql -h $DB_HOST -u $DB_USER ${DB_PASSWORD:+-p$DB_PASSWORD} $DB_NAME < weather_forecast_schema.sql

if [ $? -eq 0 ]; then
    echo -e "${GREEN}Database schema created successfully.${NC}"
else
    echo -e "${RED}Failed to create database schema.${NC}"
    exit 1
fi

# Run the views script
echo -e "${YELLOW}Creating database views...${NC}"
mysql -h $DB_HOST -u $DB_USER ${DB_PASSWORD:+-p$DB_PASSWORD} $DB_NAME < weather_forecast_views.sql

# Run the procedures script
echo -e "${YELLOW}Creating stored procedures...${NC}"
mysql -h $DB_HOST -u $DB_USER ${DB_PASSWORD:+-p$DB_PASSWORD} $DB_NAME < weather_forecast_procedures.sql

# Run the triggers script
echo -e "${YELLOW}Creating triggers...${NC}"
mysql -h $DB_HOST -u $DB_USER ${DB_PASSWORD:+-p$DB_PASSWORD} $DB_NAME < weather_forecast_triggers.sql

# Run the indexes script
echo -e "${YELLOW}Creating additional indexes...${NC}"
mysql -h $DB_HOST -u $DB_USER ${DB_PASSWORD:+-p$DB_PASSWORD} $DB_NAME < weather_forecast_indexes.sql

echo -e "${GREEN}Weather Forecast Database setup completed successfully!${NC}"
echo -e "${YELLOW}You can now run your Laravel application with this database.${NC}"
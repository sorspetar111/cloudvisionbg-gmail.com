<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\WeatherController;
use App\Http\Controllers\SubscriptionController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->group(function () {
    // User routes
    Route::get('/user', function (Request $request) {
        return $request->user();
    });
    
    // Weather routes
    Route::prefix('weather')->group(function () {
        Route::get('/forecast', [WeatherController::class, 'getWeatherForecast']);
        Route::post('/send-email', [WeatherController::class, 'sendWeatherEmail']);
    });
    
    // Subscription routes
    Route::prefix('subscriptions')->group(function () {
        Route::post('/', [SubscriptionController::class, 'create']);
        Route::delete('/', [SubscriptionController::class, 'cancel']);
        Route::get('/current', [SubscriptionController::class, 'getCurrentSubscription']);
        Route::put('/location', [SubscriptionController::class, 'updateLocation']);
    });
});
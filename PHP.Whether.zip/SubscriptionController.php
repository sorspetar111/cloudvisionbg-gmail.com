
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Subscription;
use Illuminate\Support\Facades\Mail;
use App\Mail\WeatherForecastMail;
use App\Http\Controllers\WeatherController;

class SubscriptionController extends Controller
{
    /**
     * Subscribe to daily weather forecasts.
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function subscribe(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'location' => 'required|string',
        ]);

        $user = User::firstOrCreate(['email' => $request->email]);

        $subscription = $user->subscriptions()->create([
            'location' => $request->location,
            'status' => 'active',
        ]);

        return response()->json([
            'message' => 'Subscription successful',
            'subscription_id' => $subscription->id,
        ], 201);
    }

    /**
     * Unsubscribe from daily weather forecasts.
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function unsubscribe(Request $request)
    {
        $request->validate([
            'subscription_id' => 'required|integer|exists:subscriptions,id',
        ]);

        $subscription = Subscription::find($request->subscription_id);
        $subscription->update(['status' => 'inactive']);

        return response()->json([
            'message' => 'Unsubscription successful',
        ]);
    }

    /**
     * Send daily forecasts to active subscribers.
     * (Called by Laravel Scheduler)
     */
    public function sendDailyForecasts()
    {
        $subscriptions = Subscription::where('status', 'active')->get();

        foreach ($subscriptions as $subscription) {
            // Use WeatherController to fetch weather data
            $weatherController = new WeatherController();
       
             $weather = $weatherController->fetchWeatherData($subscription->location);
         //        $weather = $weatherController->getWeather($subscription->location);


            // Send email
            Mail::to($subscription->user->email)->send(
                new WeatherForecastMail($subscription->location, $weather)
            );
        }
    }
    
}
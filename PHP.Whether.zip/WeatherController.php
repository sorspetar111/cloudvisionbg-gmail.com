
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;

class WeatherController extends Controller
{
    
    public function getWeather(Request $request)
    {
        $request->validate([
            'location' => 'required|string',
        ]);

        $weather = $this->fetchWeatherData($request->location);

        return response()->json([
            'location' => $request->location,
            'temperature' => $weather['main']['temp'],
            'wind_speed' => $weather['wind']['speed'],
            'precipitation' => $weather['weather'][0]['description'],
            'description' => $weather['weather'][0]['main'],
        ]);
    }

  
    public function fetchWeatherData($location)
    {
        $client = new Client();
        $response = $client->get('https://api.openweathermap.org/data/2.5/weather', [
            'query' => [
                'q' => $location,
                'appid' => env('OPENWEATHERMAP_API_KEY'),
                'units' => 'metric',
            ],
        ]);

        return json_decode($response->getBody(), true);
    }
    
}
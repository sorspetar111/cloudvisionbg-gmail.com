<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class WeatherForecastMail extends Mailable
{
    use Queueable, SerializesModels;

    public $location;
    public $weather;

    /**
     * Create a new message instance.
     *
     * @param string $location
     * @param array $weather
     * @return void
     */
    public function __construct($location, $weather)
    {
        $this->location = $location;
        $this->weather = $weather;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject("Today's Weather Forecast for {$this->location}")
                    ->view('emails.weather-forecast');
    }
}

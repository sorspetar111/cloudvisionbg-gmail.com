<!DOCTYPE html>
<html>
<head>
    <title>Weather Forecast</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background-color: #4a90e2;
            color: white;
            padding: 15px;
            text-align: center;
            border-radius: 5px 5px 0 0;
        }
        .content {
            padding: 20px;
            border: 1px solid #ddd;
            border-top: none;
            border-radius: 0 0 5px 5px;
        }
        .weather-info {
            margin: 20px 0;
        }
        .footer {
            text-align: center;
            font-size: 12px;
            color: #777;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Today's Weather Forecast</h1>
    </div>
    
    <div class="content">
        <p>Hello,</p>
        
        <p>Here is your daily weather forecast for <strong>{{ $location }}</strong>:</p>
        
        <div class="weather-info">
            <p><strong>Temperature:</strong> {{ $weather['main']['temp'] }}°C</p>
            <p><strong>Condition:</strong> {{ $weather['weather'][0]['main'] }}</p>
            <p><strong>Description:</strong> {{ $weather['weather'][0]['description'] }}</p>
            <p><strong>Wind Speed:</strong> {{ $weather['wind']['speed'] }} m/s</p>
            <p><strong>Humidity:</strong> {{ $weather['main']['humidity'] }}%</p>
        </div>
        
        <p>Have a great day!</p>
    </div>
    
    <div class="footer">
        <p>You received this email because you're subscribed to our Weather Forecast service.</p>
        <p>To unsubscribe, use the unsubscribe endpoint with your subscription ID.</p>
    </div>
</body>
</html>

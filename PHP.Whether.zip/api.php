
use App\Http\Controllers\WeatherController;
use App\Http\Controllers\SubscriptionController;


Route::get('/weather', [WeatherController::class, 'getWeather']);
Route::get('/weather2', [WeatherController::class, 'fetchWeatherData']);


Route::post('/subscribe', [SubscriptionController::class, 'subscribe']);
Route::post('/unsubscribe', [SubscriptionController::class, 'unsubscribe']);

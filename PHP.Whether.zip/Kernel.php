
protected function schedule(Schedule $schedule)
{
    $schedule->call([SubscriptionController::class, 'sendDailyForecasts'])
             ->dailyAt('08:00'); 
}

// testing debug info
//protected function schedule2(Schedule $schedule)
//  {
//      $schedule->call(function () {
//          $subscriptions = Subscription::where('status', 'active')->get();
//          foreach ($subscriptions as $subscription) {
//              $weather = $this->getWeather($subscription->location);
//              Mail::to($subscription->user->email)->send(new WeatherForecastMail($subscription->location, $weather));
//          }
//      })->daily();
//  }
  